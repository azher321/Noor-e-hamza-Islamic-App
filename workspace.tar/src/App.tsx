import { useState, useEffect } from 'react';
import {
  quranVerses,
  hadithCollection,
  wuzuSteps,
  salahGuide,
  zakatInfo,
  hajjGuide,
  umrahGuide,
  islamicBusiness,
  islamicHistory,
  ethicsAndAkhlaq,
  jihadInfo,
  fiqhBooks
} from './data/islamicContent';

type Language = 'en' | 'ur' | 'ar';
type Section = 'home' | 'quran' | 'hadith' | 'wuzu' | 'salah' | 'zakat' | 'hajj' | 'umrah' | 'business' | 'history' | 'ethics' | 'jihad' | 'fiqh' | 'mosques';

export default function App() {
  const [currentSection, setCurrentSection] = useState<Section>('home');
  const [language, setLanguage] = useState<Language>('en');
  const [menuOpen, setMenuOpen] = useState(false);
  const [zakatWealth, setZakatWealth] = useState(0);
  const [zakatGold, setZakatGold] = useState(0);
  const [zakatSilver, setZakatSilver] = useState(0);
  const [zakatDebts, setZakatDebts] = useState(0);

  useEffect(() => {
    const savedLang = localStorage.getItem('islamic-app-lang') as Language;
    if (savedLang) setLanguage(savedLang);
  }, []);

  useEffect(() => {
    localStorage.setItem('islamic-app-lang', language);
  }, [language]);

  const dir = language === 'ar' || language === 'ur' ? 'rtl' : 'ltr';

  const menuItems: { id: Section; icon: string; label: { en: string; ur: string; ar: string } }[] = [
    { id: 'home', icon: '🕌', label: { en: 'Home', ur: 'ہوم', ar: 'الرئيسية' } },
    { id: 'quran', icon: '📖', label: { en: 'Holy Quran', ur: 'قرآن مجید', ar: 'القرآن الكريم' } },
    { id: 'hadith', icon: '📚', label: { en: 'Hadith Books', ur: 'کتب حدیث', ar: 'كتب الحديث' } },
    { id: 'wuzu', icon: '💧', label: { en: 'Wuzu Guide', ur: 'وضو', ar: 'الوضوء' } },
    { id: 'salah', icon: '🤲', label: { en: 'Salah Guide', ur: 'نماز', ar: 'الصلاة' } },
    { id: 'zakat', icon: '💰', label: { en: 'Zakat', ur: 'زکوٰۃ', ar: 'الزكاة' } },
    { id: 'hajj', icon: '🕋', label: { en: 'Hajj Guide', ur: 'حج', ar: 'الحج' } },
    { id: 'umrah', icon: '🌙', label: { en: 'Umrah Guide', ur: 'عمرہ', ar: 'العمرة' } },
    { id: 'business', icon: '💼', label: { en: 'Islamic Business', ur: 'اسلامی کاروبار', ar: 'الأعمال الإسلامية' } },
    { id: 'ethics', icon: '⭐', label: { en: 'Ethics & Akhlaq', ur: 'اخلاقیات', ar: 'الأخلاق' } },
    { id: 'jihad', icon: '📜', label: { en: 'Jihad in Islam', ur: 'جہاد', ar: 'الجهاد' } },
    { id: 'history', icon: '📜', label: { en: 'Islamic History', ur: 'اسلامی تاریخ', ar: 'التاريخ الإسلامي' } },
    { id: 'fiqh', icon: '📕', label: { en: 'Fiqh Books', ur: 'کتب فقہ', ar: 'كتب الفقه' } },
    { id: 'mosques', icon: '🗺️', label: { en: 'Nearby Mosques', ur: 'قریبی مساجد', ar: 'المساجد القريبة' } },
  ];

  const renderContent = () => {
    switch (currentSection) {
      case 'home': return <HomeSection language={language} setCurrentSection={setCurrentSection} />;
      case 'quran': return <QuranSection language={language} />;
      case 'hadith': return <HadithSection language={language} />;
      case 'wuzu': return <WuzuSection language={language} />;
      case 'salah': return <SalahSection language={language} />;
      case 'zakat': return <ZakatSection language={language} wealth={zakatWealth} setWealth={setZakatWealth} gold={zakatGold} setGold={setZakatGold} silver={zakatSilver} setSilver={setZakatSilver} debts={zakatDebts} setDebts={setZakatDebts} />;
      case 'hajj': return <HajjSection language={language} />;
      case 'umrah': return <UmrahSection language={language} />;
      case 'business': return <BusinessSection language={language} />;
      case 'ethics': return <EthicsSection language={language} />;
      case 'jihad': return <JihadSection language={language} />;
      case 'history': return <HistorySection language={language} />;
      case 'fiqh': return <FiqhSection language={language} />;
      case 'mosques': return <MosquesSection language={language} />;
      default: return <HomeSection language={language} setCurrentSection={setCurrentSection} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-teal-50" dir={dir}>
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">☪</span>
            <div>
              <h1 className="text-lg font-bold leading-tight">نور الهداية</h1>
              <p className="text-xs text-emerald-200">Noor ul Hidayah</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="bg-emerald-700 text-white text-xs px-2 py-1 rounded border border-emerald-600"
            >
              <option value="en">English</option>
              <option value="ur">اردو</option>
              <option value="ar">العربية</option>
            </select>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-2 rounded-lg bg-emerald-700 hover:bg-emerald-600 transition"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {menuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-black/50" onClick={() => setMenuOpen(false)}>
          <div className="absolute top-16 right-0 w-72 max-h-[80vh] overflow-y-auto bg-white rounded-l-2xl shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="p-4">
              <div className="text-center mb-4 pb-4 border-b border-emerald-100">
                <p className="text-emerald-800 font-bold text-sm">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
                <p className="text-xs text-gray-500 mt-1">In the name of Allah</p>
              </div>
              <nav className="space-y-1">
                {menuItems.map(item => (
                  <button
                    key={item.id}
                    onClick={() => { setCurrentSection(item.id); setMenuOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition ${
                      currentSection === item.id
                        ? 'bg-emerald-100 text-emerald-800 font-semibold'
                        : 'hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <span className="text-xl">{item.icon}</span>
                    <span className="text-sm">{item.label[language]}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-lg mx-auto px-4 py-4 pb-24">
        {renderContent()}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-30">
        <div className="max-w-lg mx-auto flex justify-around py-2">
          {[
            { id: 'home' as Section, icon: '🏠', label: { en: 'Home', ur: 'ہوم', ar: 'رئيسي' } },
            { id: 'salah' as Section, icon: '🤲', label: { en: 'Salah', ur: 'نماز', ar: 'صلاة' } },
            { id: 'quran' as Section, icon: '📖', label: { en: 'Quran', ur: 'قرآن', ar: 'قرآن' } },
            { id: 'zakat' as Section, icon: '💰', label: { en: 'Zakat', ur: 'زکوٰۃ', ar: 'زكاة' } },
            { id: 'hajj' as Section, icon: '🕋', label: { en: 'Hajj', ur: 'حج', ar: 'حج' } },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setCurrentSection(item.id)}
              className={`flex flex-col items-center p-2 rounded-lg transition ${
                currentSection === item.id ? 'text-emerald-700 bg-emerald-50' : 'text-gray-500'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className="text-[10px] mt-0.5">{item.label[language]}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

// ============ SECTION COMPONENTS ============

function HomeSection({ language, setCurrentSection }: { language: Language; setCurrentSection: (s: Section) => void }) {
  const dailyVerse = quranVerses[Math.floor(Date.now() / 86400000) % quranVerses.length];
  const dailyHadith = hadithCollection[Math.floor(Date.now() / 86400000) % hadithCollection.length];

  return (
    <div className="space-y-4">
      {/* Bismillah Header */}
      <div className="bg-gradient-to-br from-emerald-700 to-teal-800 rounded-2xl p-6 text-white text-center shadow-xl">
        <p className="font-arabic text-2xl mb-2 leading-loose">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
        <p className="text-emerald-100 text-sm">
          {language === 'en' ? 'In the name of Allah, the Most Gracious, the Most Merciful' :
           language === 'ur' ? 'اللہ کے نام سے جو بڑا مہربان نہایت رحم والا ہے' :
           'بسم الله الرحمن الرحيم'}
        </p>
      </div>

      {/* Daily Verse */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-emerald-100">
        <h3 className="text-emerald-800 font-bold text-sm mb-3 flex items-center gap-2">
          📖 {language === 'en' ? 'Verse of the Day' : language === 'ur' ? 'آج کی آیت' : 'آية اليوم'}
        </h3>
        <p className="font-arabic text-xl text-right text-emerald-900 mb-3 leading-loose">{dailyVerse.arabic}</p>
        <p className="text-gray-700 text-sm mb-2">
          {language === 'en' ? dailyVerse.translation_en : dailyVerse.translation_ur}
        </p>
        <p className="text-xs text-emerald-600 font-medium">{dailyVerse.reference}</p>
      </div>

      {/* Daily Hadith */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-teal-100">
        <h3 className="text-teal-800 font-bold text-sm mb-3 flex items-center gap-2">
          📚 {language === 'en' ? 'Hadith of the Day' : language === 'ur' ? 'آج کی حدیث' : 'حديث اليوم'}
        </h3>
        <p className="font-arabic text-lg text-right text-teal-900 mb-3 leading-loose">{dailyHadith.text_ar}</p>
        <p className="text-gray-700 text-sm mb-2">
          {language === 'en' ? dailyHadith.text_en : dailyHadith.text_ur}
        </p>
        <p className="text-xs text-teal-600 font-medium">— {dailyHadith.source}</p>
        <p className="text-xs text-gray-500 mt-1">{language === 'en' ? 'Narrated by' : language === 'ur' ? 'روایت از' : 'رواه'} {dailyHadith.narrator}</p>
      </div>

      {/* Quick Access Grid */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { id: 'wuzu' as Section, icon: '💧', label: language === 'en' ? 'Wuzu' : language === 'ur' ? 'وضو' : 'وضوء' },
          { id: 'salah' as Section, icon: '🤲', label: language === 'en' ? 'Salah' : language === 'ur' ? 'نماز' : 'صلاة' },
          { id: 'hajj' as Section, icon: '🕋', label: language === 'en' ? 'Hajj' : language === 'ur' ? 'حج' : 'حج' },
          { id: 'umrah' as Section, icon: '🌙', label: language === 'en' ? 'Umrah' : language === 'ur' ? 'عمرہ' : 'عمرة' },
          { id: 'business' as Section, icon: '💼', label: language === 'en' ? 'Business' : language === 'ur' ? 'کاروبار' : 'أعمال' },
          { id: 'ethics' as Section, icon: '⭐', label: language === 'en' ? 'Ethics' : language === 'ur' ? 'اخلاق' : 'أخلاق' },
          { id: 'history' as Section, icon: '📜', label: language === 'en' ? 'History' : language === 'ur' ? 'تاریخ' : 'تاريخ' },
          { id: 'fiqh' as Section, icon: '📕', label: language === 'en' ? 'Fiqh' : language === 'ur' ? 'فقہ' : 'فقه' },
          { id: 'mosques' as Section, icon: '🗺️', label: language === 'en' ? 'Mosques' : language === 'ur' ? 'مساجد' : 'مساجد' },
        ].map(item => (
          <button
            key={item.id}
            onClick={() => setCurrentSection(item.id)}
            className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:border-emerald-300 hover:shadow-md transition flex flex-col items-center gap-2"
          >
            <span className="text-2xl">{item.icon}</span>
            <span className="text-xs font-medium text-gray-700">{item.label}</span>
          </button>
        ))}
      </div>

      {/* Five Pillars */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-emerald-100">
        <h3 className="text-emerald-800 font-bold text-sm mb-4">
          {language === 'en' ? '🏛️ Five Pillars of Islam' : language === 'ur' ? '🏛️ ارکان اسلام' : '🏛️ أركان الإسلام'}
        </h3>
        <div className="space-y-3">
          {[
            { en: 'Shahada (Testimony of Faith)', ur: 'شہادت (کلمہ)', ar: 'الشهادة' },
            { en: 'Salah (Prayer)', ur: 'نماز', ar: 'الصلاة' },
            { en: 'Zakat (Charity)', ur: 'زکوٰۃ', ar: 'الزكاة' },
            { en: 'Sawm (Fasting)', ur: 'روزہ', ar: 'الصوم' },
            { en: 'Hajj (Pilgrimage)', ur: 'حج', ar: 'الحج' },
          ].map((pillar, i) => (
            <div key={i} className="flex items-center gap-3 bg-emerald-50 rounded-lg p-3">
              <span className="w-7 h-7 bg-emerald-700 text-white rounded-full flex items-center justify-center text-xs font-bold">{i + 1}</span>
              <span className="text-sm text-gray-700">{pillar[language]}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Articles of Faith */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-teal-100">
        <h3 className="text-teal-800 font-bold text-sm mb-4">
          {language === 'en' ? '🌟 Six Articles of Faith (Iman)' : language === 'ur' ? '🌟 ایمان کے ارکان' : '🌟 أركان الإيمان'}
        </h3>
        <div className="space-y-2">
          {[
            { en: 'Belief in Allah', ur: 'اللہ پر ایمان', ar: 'الإيمان بالله' },
            { en: 'Belief in Angels', ur: 'فرشتوں پر ایمان', ar: 'الإيمان بالملائكة' },
            { en: 'Belief in Divine Books', ur: 'آسمانی کتابوں پر ایمان', ar: 'الإيمان بالكتب' },
            { en: 'Belief in Prophets', ur: 'انبیاء پر ایمان', ar: 'الإيمان بالرسل' },
            { en: 'Belief in Day of Judgment', ur: 'یوم آخرت پر ایمان', ar: 'الإيمان باليوم الآخر' },
            { en: 'Belief in Divine Decree', ur: 'تقدیر پر ایمان', ar: 'الإيمان بالقدر' },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-2 text-sm text-gray-700 py-1">
              <span className="text-teal-600">✦</span>
              <span>{item[language]}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-gray-500 mt-3 italic">
          {language === 'en' ? 'Reference: Sahih Muslim, Hadith 8 (Hadith Jibreel)' :
           language === 'ur' ? 'حوالہ: صحیح مسلم، حدیث 8 (حدیث جبرائیل)' :
           'المرجع: صحيح مسلم، حديث 8 (حديث جبريل)'}
        </p>
      </div>
    </div>
  );
}

function QuranSection({ language }: { language: Language }) {
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-emerald-700 to-teal-800 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{language === 'en' ? 'Holy Quran' : language === 'ur' ? 'قرآن مجید' : 'القرآن الكريم'}</h2>
        <p className="text-emerald-200 text-xs">{language === 'en' ? 'Selected verses with translation' : language === 'ur' ? 'ترجمہ کے ساتھ منتخب آیات' : 'آيات مختارة مع الترجمة'}</p>
      </div>

      {quranVerses.map(verse => (
        <div key={verse.id} className="bg-white rounded-2xl p-5 shadow-md border border-emerald-100">
          <p className="font-arabic text-xl text-right text-emerald-900 mb-3 leading-loose border-b border-emerald-50 pb-3">{verse.arabic}</p>
          <p className="text-gray-700 text-sm mb-2">
            {language === 'en' ? verse.translation_en : verse.translation_ur}
          </p>
          <p className="text-xs text-emerald-600 font-semibold">📍 {verse.reference}</p>
        </div>
      ))}

      <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200">
        <h4 className="text-amber-800 font-bold text-sm mb-2">{language === 'en' ? '📚 Complete Quran Resources' : language === 'ur' ? '📚 مکمل قرآنی وسائل' : '📚 موارد القرآن الكاملة'}</h4>
        <ul className="text-xs text-gray-700 space-y-1">
          <li>• {language === 'en' ? 'Quran has 114 Surahs (chapters)' : language === 'ur' ? 'قرآن میں 114 سورتیں ہیں' : 'يحتوي القرآن على 114 سورة'}</li>
          <li>• {language === 'en' ? '6,236 Ayahs (verses)' : language === 'ur' ? '6236 آیات ہیں' : '6236 آية'}</li>
          <li>• {language === 'en' ? '30 Juz (parts)' : language === 'ur' ? '30 پارے ہیں' : '30 جزء'}</li>
          <li>• {language === 'en' ? 'Revealed over 23 years' : language === 'ur' ? '23 سال میں نازل ہوا' : 'نزل على مدى 23 سنة'}</li>
        </ul>
        <p className="text-xs text-amber-700 mt-2 font-medium">{language === 'en' ? 'Reference: Quran 15:9 - Allah has promised to protect the Quran' : language === 'ur' ? 'حوالہ: قرآن 15:9 - اللہ نے قرآن کی حفاظت کا وعدہ فرمایا' : 'المرجع: القرآن 15:9'}</p>
      </div>
    </div>
  );
}

function HadithSection({ language }: { language: Language }) {
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-teal-700 to-emerald-800 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{language === 'en' ? 'Hadith Collections' : language === 'ur' ? 'کتب حدیث' : 'كتب الحديث'}</h2>
        <p className="text-teal-200 text-xs">{language === 'en' ? 'Sayings of Prophet Muhammad ﷺ' : language === 'ur' ? 'نبی کریم ﷺ کے ارشادات' : 'أقوال النبي محمد ﷺ'}</p>
      </div>

      {hadithCollection.map(hadith => (
        <div key={hadith.id} className="bg-white rounded-2xl p-5 shadow-md border border-teal-100">
          <p className="font-arabic text-lg text-right text-teal-900 mb-3 leading-loose">{hadith.text_ar}</p>
          <p className="text-gray-700 text-sm mb-3">
            {language === 'en' ? hadith.text_en : hadith.text_ur}
          </p>
          <div className="border-t border-teal-50 pt-2">
            <p className="text-xs text-teal-700 font-semibold">📖 {hadith.source}</p>
            <p className="text-xs text-gray-500">{language === 'en' ? 'Narrated by' : language === 'ur' ? 'روایت از' : 'رواه'} {hadith.narrator}</p>
          </div>
        </div>
      ))}

      <div className="bg-white rounded-2xl p-5 shadow-md border border-gray-100">
        <h4 className="text-gray-800 font-bold text-sm mb-3">{language === 'en' ? '📚 Six Major Hadith Books (Kutub as-Sittah)' : language === 'ur' ? '📚 چھ بڑی کتب حدیث' : '📚 الكتب الستة'}</h4>
        <div className="space-y-2">
          {[
            { name: 'Sahih al-Bukhari', author: 'Imam Bukhari (810-870 CE)', hadiths: '7,563' },
            { name: 'Sahih Muslim', author: 'Imam Muslim (815-875 CE)', hadiths: '7,500' },
            { name: 'Sunan Abu Dawud', author: 'Imam Abu Dawud (817-889 CE)', hadiths: '5,274' },
            { name: 'Jami at-Tirmidhi', author: 'Imam at-Tirmidhi (824-892 CE)', hadiths: '3,956' },
            { name: 'Sunan an-Nasa\'i', author: 'Imam an-Nasa\'i (829-915 CE)', hadiths: '5,758' },
            { name: 'Sunan Ibn Majah', author: 'Imam Ibn Majah (824-887 CE)', hadiths: '4,341' },
          ].map((book, i) => (
            <div key={i} className="bg-gray-50 rounded-lg p-3">
              <p className="text-sm font-semibold text-gray-800">{book.name}</p>
              <p className="text-xs text-gray-500">{book.author} | {book.hadiths} hadiths</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function WuzuSection({ language }: { language: Language }) {
  const data = wuzuSteps[language];
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-blue-600 to-cyan-700 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-blue-200 text-xs">{language === 'en' ? 'Step-by-step guide with Hanafi Fiqh' : language === 'ur' ? 'حنفی فقہ کے ساتھ مرحلہ وار رہنمائی' : 'دليل خطوة بخطوة حسب الفقه الحنفي'}</p>
      </div>

      {/* Fard Acts */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-blue-100">
        <h3 className="text-blue-800 font-bold text-sm mb-3">
          {language === 'en' ? '🔴 Fard (Obligatory) Acts - 4' : language === 'ur' ? '🔴 فرض اعمال - 4' : '🔴 أركان الوضوء - 4'}
        </h3>
        <div className="space-y-2">
          {data.fard.map((step, i) => (
            <div key={i} className="bg-blue-50 rounded-lg p-3 text-sm text-gray-700">{step}</div>
          ))}
        </div>
      </div>

      {/* Sunnah Acts */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-emerald-100">
        <h3 className="text-emerald-800 font-bold text-sm mb-3">
          {language === 'en' ? '🟢 Sunnah Acts (Complete Method)' : language === 'ur' ? '🟢 سنت اعمال (مکمل طریقہ)' : '🟢 السنن'}
        </h3>
        <div className="space-y-2">
          {data.sunnah.map((step, i) => (
            <div key={i} className="bg-emerald-50 rounded-lg p-3 text-sm text-gray-700">{step}</div>
          ))}
        </div>
      </div>

      {/* Dua after Wuzu */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-amber-100">
        <h3 className="text-amber-800 font-bold text-sm mb-3">
          {language === 'en' ? '🤲 Dua After Wuzu' : language === 'ur' ? '🤲 وضو کے بعد کی دعا' : '🤲 دعاء بعد الوضوء'}
        </h3>
        <p className="font-arabic text-xl text-right text-amber-900 mb-3 leading-loose">{data.dua}</p>
        <p className="text-sm text-gray-700">{data.duaTranslation}</p>
      </div>

      {/* Reference */}
      <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
        <p className="text-xs text-gray-600">📖 {language === 'en' ? 'Reference' : language === 'ur' ? 'حوالہ' : 'المرجع'}: {data.reference}</p>
        <p className="text-xs text-emerald-700 mt-2 font-medium">📝 {language === 'en' ? 'Hanafi Note' : language === 'ur' ? 'حنفی نوٹ' : 'ملاحظة حنفية'}: {data.fiqhNote}</p>
      </div>

      {/* Things that break wuzu */}
      <div className="bg-red-50 rounded-2xl p-5 border border-red-100">
        <h3 className="text-red-800 font-bold text-sm mb-3">
          {language === 'en' ? '⚠️ Things that Break Wuzu (Hanafi Fiqh)' : language === 'ur' ? '⚠️ وضو توڑنے والے امور (حنفی)' : '⚠️ نواقض الوضوء'}
        </h3>
        <ul className="text-sm text-gray-700 space-y-1">
          <li>• {language === 'en' ? 'Discharge from private parts' : language === 'ur' ? 'پاخانہ، پیشاب، ہوا خارج ہونا' : 'خروج من السبيلين'}</li>
          <li>• {language === 'en' ? 'Deep sleep' : language === 'ur' ? 'گہری نیند' : 'النوم العميق'}</li>
          <li>• {language === 'en' ? 'Loss of consciousness' : language === 'ur' ? 'بے ہوشی' : 'فقدان الوعي'}</li>
          <li>• {language === 'en' ? 'Vomiting (mouthful)' : language === 'ur' ? 'منہ بھر قے' : 'القيء الملء'}</li>
          <li>• {language === 'en' ? 'Bleeding that flows beyond wound' : language === 'ur' ? 'زخم سے بہہ کر خون نکلنا' : 'خروج الدم السائل'}</li>
        </ul>
        <p className="text-xs text-red-600 mt-2">📖 {language === 'en' ? 'Reference: Radd al-Muhtar (Ibn Abidin), Vol. 1' : language === 'ur' ? 'حوالہ: رد المحتار (ابن عابدین)، جلد 1' : 'المرجع: رد المحتار، الجزء 1'}</p>
      </div>
    </div>
  );
}

function SalahSection({ language }: { language: Language }) {
  const data = salahGuide.en;
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-purple-700 to-indigo-800 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-purple-200 text-xs">{language === 'en' ? 'According to Hanafi Fiqh' : language === 'ur' ? 'حنفی فقہ کے مطابق' : 'حسب الفقه الحنفي'}</p>
      </div>

      {/* Daily Prayers */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-purple-100">
        <h3 className="text-purple-800 font-bold text-sm mb-3">
          {language === 'en' ? '🕐 Five Daily Prayers' : language === 'ur' ? '🕐 پانچ وقت کی نمازیں' : '🕐 الصلوات الخمس'}
        </h3>
        <div className="space-y-2">
          {data.dailyPrayers.map((prayer, i) => (
            <div key={i} className="bg-purple-50 rounded-lg p-3">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-sm text-purple-900">{prayer.name}</span>
                <span className="text-xs text-purple-600">{prayer.total} Rakaat</span>
              </div>
              <p className="text-xs text-gray-600 mt-1">{prayer.time}</p>
              <p className="text-xs text-gray-500 mt-1">{prayer.rakaat}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Steps */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-indigo-100">
        <h3 className="text-indigo-800 font-bold text-sm mb-3">
          {language === 'en' ? '📋 Steps of Salah' : language === 'ur' ? '📋 نماز کے ارکان' : '📋 خطوات الصلاة'}
        </h3>
        <div className="space-y-2">
          {data.steps.map((step, i) => (
            <div key={i} className="bg-indigo-50 rounded-lg p-3 text-sm text-gray-700">{step}</div>
          ))}
        </div>
      </div>

      {/* Important Recitations */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-amber-100">
        <h3 className="text-amber-800 font-bold text-sm mb-3">
          {language === 'en' ? '🤲 Important Recitations' : language === 'ur' ? '🤲 اہم قراءت' : '🤲 القراءات المهمة'}
        </h3>
        {Object.entries(data.importantRecitations).map(([key, recitation]) => (
          <div key={key} className="mb-4 pb-4 border-b border-amber-50 last:border-0">
            <p className="text-xs font-semibold text-amber-700 mb-2 capitalize">{key === 'thana' ? 'Thana (Opening Supplication)' : key === 'tashahhud' ? 'Tashahhud (Attahiyyat)' : 'Durood Ibrahim'}</p>
            <p className="font-arabic text-lg text-right text-amber-900 mb-2 leading-loose">{recitation.arabic}</p>
            <p className="text-xs text-gray-600">{recitation.translation}</p>
          </div>
        ))}
      </div>

      {/* Hanafi Fiqh Notes */}
      <div className="bg-emerald-50 rounded-2xl p-5 border border-emerald-200">
        <h3 className="text-emerald-800 font-bold text-sm mb-3">
          {language === 'en' ? '📝 Hanafi Fiqh Specific Notes' : language === 'ur' ? '📝 حنفی فقہ کے خاص نکات' : '📝 ملاحظات الفقه الحنفي'}
        </h3>
        <ul className="text-sm text-gray-700 space-y-2">
          {data.fiqhNotes.map((note, i) => (
            <li key={i} className="flex items-start gap-2">
              <span className="text-emerald-600 mt-0.5">•</span>
              <span>{note}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
        <p className="text-xs text-gray-600">📖 {language === 'en' ? 'Reference' : language === 'ur' ? 'حوالہ' : 'المرجع'}: {data.reference}</p>
      </div>
    </div>
  );
}

function ZakatSection({ language, wealth, setWealth, gold, setGold, silver, setSilver, debts, setDebts }: {
  language: Language; wealth: number; setWealth: (v: number) => void;
  gold: number; setGold: (v: number) => void; silver: number; setSilver: (v: number) => void;
  debts: number; setDebts: (v: number) => void;
}) {
  const data = zakatInfo.en;
  const totalWealth = wealth + (gold * 60) + (silver * 0.8); // Approximate values
  const netWealth = totalWealth - debts;
  const zakatDue = netWealth > 0 ? netWealth * 0.025 : 0;
  // Nisaab for silver approx: 612.36g × 0.8 USD/g ≈ $490
  const nisaabMet = netWealth >= 490;

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-yellow-600 to-amber-700 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-yellow-200 text-xs">{language === 'en' ? 'Calculator & Complete Guide' : language === 'ur' ? 'کیلکولیٹر اور مکمل رہنمائی' : 'حاسبة ودليل شامل'}</p>
      </div>

      {/* Calculator */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-amber-100">
        <h3 className="text-amber-800 font-bold text-sm mb-4">
          {language === 'en' ? '🧮 Zakat Calculator' : language === 'ur' ? '🧮 زکوٰۃ کیلکولیٹر' : '🧮 حاسبة الزكاة'}
        </h3>
        <div className="space-y-3">
          <div>
            <label className="text-xs text-gray-600 block mb-1">{language === 'en' ? 'Cash & Bank Balance (USD)' : language === 'ur' ? 'نقد اور بینک بیلنس (ڈالر)' : 'النقد والرصيد (دولار)'}</label>
            <input type="number" value={wealth || ''} onChange={e => setWealth(Number(e.target.value))} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" placeholder="0" />
          </div>
          <div>
            <label className="text-xs text-gray-600 block mb-1">{language === 'en' ? 'Gold (grams)' : language === 'ur' ? 'سونا (گرام)' : 'الذهب (جرام)'}</label>
            <input type="number" value={gold || ''} onChange={e => setGold(Number(e.target.value))} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" placeholder="0" />
          </div>
          <div>
            <label className="text-xs text-gray-600 block mb-1">{language === 'en' ? 'Silver (grams)' : language === 'ur' ? 'چاندی (گرام)' : 'الفضة (جرام)'}</label>
            <input type="number" value={silver || ''} onChange={e => setSilver(Number(e.target.value))} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" placeholder="0" />
          </div>
          <div>
            <label className="text-xs text-gray-600 block mb-1">{language === 'en' ? 'Debts & Liabilities (USD)' : language === 'ur' ? 'قرضے (ڈالر)' : 'الديون (دولار)'}</label>
            <input type="number" value={debts || ''} onChange={e => setDebts(Number(e.target.value))} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" placeholder="0" />
          </div>
        </div>

        <div className="mt-4 p-4 bg-amber-50 rounded-xl border border-amber-200">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-600">{language === 'en' ? 'Total Wealth' : language === 'ur' ? 'کل مال' : 'إجمالي المال'}:</span>
            <span className="font-bold text-amber-800">${totalWealth.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-600">{language === 'en' ? 'Net Wealth' : language === 'ur' ? 'خالص مال' : 'صافي المال'}:</span>
            <span className="font-bold text-amber-800">${netWealth.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-600">{language === 'en' ? 'Nisaab Status' : language === 'ur' ? 'نصاب' : 'حالة النصاب'}:</span>
            <span className={`font-bold ${nisaabMet ? 'text-green-600' : 'text-red-600'}`}>
              {nisaabMet ? (language === 'en' ? '✓ Nisaab Reached' : language === 'ur' ? '✓ نصاب مکمل' : '✓ بلغ النصاب') : (language === 'en' ? '✗ Below Nisaab' : language === 'ur' ? '✗ نصاب سے کم' : '✗ لم يبلغ النصاب')}
            </span>
          </div>
          <div className="border-t border-amber-300 pt-2 mt-2">
            <div className="flex justify-between">
              <span className="text-gray-700 font-semibold">{language === 'en' ? 'Zakat Due (2.5%)' : language === 'ur' ? 'زکوٰۃ (2.5%)' : 'الزكاة (2.5%)'}:</span>
              <span className="text-lg font-bold text-green-700">${zakatDue.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Nisaab Info */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-gray-100">
        <h3 className="text-gray-800 font-bold text-sm mb-3">
          {language === 'en' ? '📏 Nisaab (Minimum Threshold)' : language === 'ur' ? '📏 نصاب (کم از کم حد)' : '📏 النصاب'}
        </h3>
        <div className="space-y-2 text-sm text-gray-700">
          <p>🥇 {language === 'en' ? 'Gold' : language === 'ur' ? 'سونا' : 'الذهب'}: {data.nisaab.gold}</p>
          <p>🥈 {language === 'en' ? 'Silver' : language === 'ur' ? 'چاندی' : 'الفضة'}: {data.nisaab.silver}</p>
          <p>💵 {language === 'en' ? 'Cash' : language === 'ur' ? 'نقد' : 'النقد'}: {data.nisaab.cash}</p>
        </div>
      </div>

      {/* Eligible Recipients */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-green-100">
        <h3 className="text-green-800 font-bold text-sm mb-3">
          {language === 'en' ? '✅ 8 Categories Eligible for Zakat' : language === 'ur' ? '✅ زکوٰۃ کے مستحق 8 زمرے' : '✅ الأصناف الثمانية المستحقة للزكاة'}
        </h3>
        <div className="space-y-2">
          {data.eligibleRecipients.map((item, i) => (
            <div key={i} className="bg-green-50 rounded-lg p-2 text-sm text-gray-700">{item}</div>
          ))}
        </div>
        <p className="text-xs text-green-700 mt-3">📖 {data.reference}</p>
      </div>

      {/* What to include */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-blue-100">
        <h3 className="text-blue-800 font-bold text-sm mb-3">
          {language === 'en' ? '📋 What to Include in Zakat Calculation' : language === 'ur' ? '📋 زکوٰۃ کے حساب میں کیا شامل کریں' : '📋 ما يدخل في حساب الزكاة'}
        </h3>
        <div className="space-y-1">
          <p className="text-xs font-semibold text-green-700 mb-2">{language === 'en' ? '✓ Include:' : language === 'ur' ? '✓ شامل کریں:' : '✓ يُحتسب:'}</p>
          {data.calculation.items.map((item, i) => (
            <p key={i} className="text-sm text-gray-700 pl-3">• {item}</p>
          ))}
          <p className="text-xs font-semibold text-red-700 mb-2 mt-3">{language === 'en' ? '✗ Deduct:' : language === 'ur' ? '✗ منہا کریں:' : '✗ يُخصم:'}</p>
          {data.calculation.deductions.map((item, i) => (
            <p key={i} className="text-sm text-gray-700 pl-3">• {item}</p>
          ))}
        </div>
      </div>
    </div>
  );
}

function HajjSection({ language }: { language: Language }) {
  const data = hajjGuide.en;
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-gray-300 text-xs">{language === 'en' ? 'According to Hanafi Fiqh' : language === 'ur' ? 'حنفی فقہ کے مطابق' : 'حسب الفقه الحنفي'}</p>
      </div>

      {/* Prerequisites */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-gray-100">
        <h3 className="text-gray-800 font-bold text-sm mb-3">
          {language === 'en' ? '📋 Conditions for Hajj (Wujub)' : language === 'ur' ? '📋 حج کے شرائط وجوب' : '📋 شروط وجوب الحج'}
        </h3>
        <div className="space-y-2">
          {data.prerequisites.map((item, i) => (
            <div key={i} className="bg-gray-50 rounded-lg p-3 text-sm text-gray-700">{item}</div>
          ))}
        </div>
      </div>

      {/* Mawaqit */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-emerald-100">
        <h3 className="text-emerald-800 font-bold text-sm mb-3">
          {language === 'en' ? '📍 Mawaqit (Stations of Ihram)' : language === 'ur' ? '📍 میقات (ح کے مقامات)' : '📍 المواقيت'}
        </h3>
        <div className="space-y-2">
          {data.mawaqit.map((m, i) => (
            <div key={i} className="bg-emerald-50 rounded-lg p-3">
              <p className="font-semibold text-sm text-emerald-900">{m.name}</p>
              <p className="text-xs text-gray-600">{language === 'en' ? 'For' : language === 'ur' ? 'برائے' : 'لأهل'} {m.for}</p>
              <p className="text-xs text-gray-500">{m.distance}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Day by Day */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-amber-100">
        <h3 className="text-amber-800 font-bold text-sm mb-3">
          {language === 'en' ? '📅 Day-by-Day Hajj Rituals' : language === 'ur' ? '📅 حج کے روزانہ اعمال' : '📅 مناسك الحج يوماً بيوم'}
        </h3>
        <div className="space-y-4">
          {data.steps.map((day, i) => (
            <div key={i} className="border-l-4 border-amber-400 pl-4">
              <p className="font-semibold text-sm text-amber-900 mb-2">{day.day}</p>
              <ul className="space-y-1">
                {day.actions.map((action, j) => (
                  <li key={j} className="text-sm text-gray-700 flex items-start gap-2">
                    <span className="text-amber-500 mt-1">•</span>
                    <span>{action}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Ihram Prohibitions */}
      <div className="bg-red-50 rounded-2xl p-5 border border-red-100">
        <h3 className="text-red-800 font-bold text-sm mb-3">
          {language === 'en' ? '⚠️ Prohibitions of Ihram' : language === 'ur' ? '⚠️ احرام کی ممنوعات' : '⚠️ محظورات الإحرام'}
        </h3>
        <div className="space-y-1">
          {data.ihramProhibitions.map((item, i) => (
            <p key={i} className="text-sm text-gray-700 flex items-start gap-2">
              <span className="text-red-500">✗</span>
              <span>{item}</span>
            </p>
          ))}
        </div>
      </div>

      <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
        <p className="text-xs text-gray-600">📖 {language === 'en' ? 'Reference' : language === 'ur' ? 'حوالہ' : 'المرجع'}: {data.reference}</p>
      </div>
    </div>
  );
}

function UmrahSection({ language }: { language: Language }) {
  const data = umrahGuide.en;
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-indigo-700 to-purple-800 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-indigo-200 text-xs">{language === 'en' ? 'Step by step according to Hanafi Fiqh' : language === 'ur' ? 'حنفی فقہ کے مطابق مرحلہ وار' : 'خطوة بخطوة حسب الفقه الحنفي'}</p>
      </div>

      {/* Steps */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-indigo-100">
        <h3 className="text-indigo-800 font-bold text-sm mb-4">
          {language === 'en' ? '📋 Steps of Umrah' : language === 'ur' ? '📋 عمرہ کے ارکان' : '📋 خطوات العمرة'}
        </h3>
        <div className="space-y-4">
          {data.steps.map((step) => (
            <div key={step.step} className="bg-indigo-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-7 h-7 bg-indigo-700 text-white rounded-full flex items-center justify-center text-xs font-bold">{step.step}</span>
                <span className="font-bold text-sm text-indigo-900">{step.name}</span>
              </div>
              <p className="text-sm text-gray-700 mb-2">{step.description}</p>
              <ul className="space-y-1">
                {step.details.map((detail, i) => (
                  <li key={i} className="text-xs text-gray-600 flex items-start gap-2">
                    <span className="text-indigo-500 mt-0.5">•</span>
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Talbiyah */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-amber-100">
        <h3 className="text-amber-800 font-bold text-sm mb-3">
          {language === 'en' ? '🤲 Talbiyah' : language === 'ur' ? '🤲 تلبیہ' : '🤲 التلبية'}
        </h3>
        <p className="font-arabic text-xl text-right text-amber-900 mb-3 leading-loose">{data.talbiyah.arabic}</p>
        <p className="text-sm text-gray-700">{data.talbiyah.translation}</p>
      </div>

      <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
        <p className="text-xs text-gray-600">📖 {language === 'en' ? 'Reference' : language === 'ur' ? 'حوالہ' : 'المرجع'}: {data.reference}</p>
      </div>
    </div>
  );
}

function BusinessSection({ language }: { language: Language }) {
  const data = islamicBusiness.en;
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-green-700 to-emerald-800 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-green-200 text-xs">{language === 'en' ? 'Halal business principles & ideas' : language === 'ur' ? 'حلال کاروباری اصول اور آئیڈیاز' : 'مبادئ وأفكار الأعمال الحلال'}</p>
      </div>

      {/* Principles */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-green-100">
        <h3 className="text-green-800 font-bold text-sm mb-3">
          {language === 'en' ? '📋 Islamic Business Principles' : language === 'ur' ? '📋 اسلامی کاروباری اصول' : '📋 مبادئ الأعمال الإسلامية'}
        </h3>
        <div className="space-y-3">
          {data.principles.map((item, i) => (
            <div key={i} className="bg-green-50 rounded-lg p-3">
              <p className="font-semibold text-sm text-green-900">{item.principle}</p>
              <p className="text-xs text-gray-600 mt-1">{item.detail}</p>
              <p className="text-xs text-green-700 mt-1">📖 {item.reference}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Business Ideas */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-emerald-100">
        <h3 className="text-emerald-800 font-bold text-sm mb-3">
          {language === 'en' ? '💡 Halal Business Ideas' : language === 'ur' ? '💡 حلال کاروباری آئیڈیاز' : '💡 أفكار أعمال حلال'}
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {data.businessIdeas.map((idea, i) => (
            <div key={i} className="bg-emerald-50 rounded-lg p-2 text-xs text-gray-700 text-center">
              {idea}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
        <p className="text-xs text-gray-600">📖 {language === 'en' ? 'Reference' : language === 'ur' ? 'حوالہ' : 'المرجع'}: {data.reference}</p>
      </div>
    </div>
  );
}

function EthicsSection({ language }: { language: Language }) {
  const data = ethicsAndAkhlaq.en;
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-rose-600 to-pink-700 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-rose-200 text-xs">{language === 'en' ? 'Core virtues of Islam' : language === 'ur' ? 'اسلام کی بنیادی فضیلتیں' : 'الفضائل الأساسية في الإسلام'}</p>
      </div>

      {/* Core Virtues */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-rose-100">
        <h3 className="text-rose-800 font-bold text-sm mb-3">
          {language === 'en' ? '⭐ Core Virtues' : language === 'ur' ? '⭐ بنیادی فضائل' : '⭐ الفضائل الأساسية'}
        </h3>
        <div className="space-y-3">
          {data.coreVirtues.map((item, i) => (
            <div key={i} className="bg-rose-50 rounded-lg p-3">
              <p className="font-semibold text-sm text-rose-900">{item.virtue}</p>
              <p className="text-xs text-gray-600 mt-1">{item.description}</p>
              <p className="text-xs text-rose-700 mt-1 italic">📖 {item.hadith}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Rights */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-purple-100">
        <h3 className="text-purple-800 font-bold text-sm mb-3">
          {language === 'en' ? '🤝 Rights in Islam (Huqooq ul Ibad)' : language === 'ur' ? '🤝 اسلام میں حقوق (حقوق العباد)' : '🤝 حقوق في الإسلام'}
        </h3>
        <div className="space-y-2">
          {data.rightsInIslam.map((item, i) => (
            <div key={i} className="bg-purple-50 rounded-lg p-2 text-sm text-gray-700">
              <span className="text-purple-600 mr-2">•</span>{item}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
        <p className="text-xs text-gray-600">📖 {language === 'en' ? 'Reference' : language === 'ur' ? 'حوالہ' : 'المرجع'}: {data.reference}</p>
      </div>
    </div>
  );
}

function JihadSection({ language }: { language: Language }) {
  const data = jihadInfo.en;
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-slate-700 to-gray-800 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-slate-300 text-xs">{language === 'en' ? 'Understanding the true meaning of Jihad' : language === 'ur' ? 'جہاد کا صحیح مفہوم' : 'فهم المعنى الحقيقي للجهاد'}</p>
      </div>

      {/* Types of Jihad */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-gray-100">
        <h3 className="text-gray-800 font-bold text-sm mb-3">
          {language === 'en' ? '📋 Types of Jihad' : language === 'ur' ? '📋 جہاد کی اقسام' : '📋 أنواع الجهاد'}
        </h3>
        <div className="space-y-3">
          {data.types.map((item, i) => (
            <div key={i} className="bg-gray-50 rounded-lg p-3">
              <p className="font-semibold text-sm text-gray-900">{item.type}</p>
              <p className="text-xs text-gray-600 mt-1">{item.description}</p>
              <p className="text-xs text-emerald-700 mt-1">📖 {item.importance}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Conditions */}
      <div className="bg-amber-50 rounded-2xl p-5 border border-amber-200">
        <h3 className="text-amber-800 font-bold text-sm mb-3">
          {language === 'en' ? '⚖️ Strict Conditions for Armed Jihad' : language === 'ur' ? '⚖️ مسلح جہاد کی سخت شرائط' : '⚖️ شروط الجهاد المسلح'}
        </h3>
        <div className="space-y-2">
          {data.conditions.map((item, i) => (
            <p key={i} className="text-sm text-gray-700 flex items-start gap-2">
              <span className="text-amber-600">•</span>
              <span>{item}</span>
            </p>
          ))}
        </div>
      </div>

      <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
        <p className="text-xs text-gray-600">📖 {language === 'en' ? 'Reference' : language === 'ur' ? 'حوالہ' : 'المرجع'}: {data.reference}</p>
      </div>
    </div>
  );
}

function HistorySection({ language }: { language: Language }) {
  const data = islamicHistory.en;
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-amber-700 to-orange-800 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-amber-200 text-xs">{language === 'en' ? 'From Prophetic era to modern times' : language === 'ur' ? 'عہد نبوی سے جدید دور تک' : 'من العصر النبوي إلى العصر الحديث'}</p>
      </div>

      {/* Timeline */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-amber-100">
        <h3 className="text-amber-800 font-bold text-sm mb-4">
          {language === 'en' ? '📅 Historical Timeline' : language === 'ur' ? '📅 تاریخی خط الوقت' : '📅 الخط الزمني'}
        </h3>
        <div className="space-y-4">
          {data.periods.map((period, i) => (
            <div key={i} className="border-l-4 border-amber-400 pl-4">
              <p className="font-bold text-sm text-amber-900 mb-2">{period.era}</p>
              <ul className="space-y-1">
                {period.events.map((event, j) => (
                  <li key={j} className="text-xs text-gray-700 flex items-start gap-2">
                    <span className="text-amber-500 mt-0.5">•</span>
                    <span>{event}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended Books */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-emerald-100">
        <h3 className="text-emerald-800 font-bold text-sm mb-3">
          {language === 'en' ? '📚 Recommended History Books' : language === 'ur' ? '📚 تجویز کردہ کتب تاریخ' : '📚 كتب التاريخ الموصى بها'}
        </h3>
        <div className="space-y-2">
          {data.recommendedBooks.map((book, i) => (
            <div key={i} className="bg-emerald-50 rounded-lg p-3">
              <p className="font-semibold text-sm text-emerald-900">{book.title}</p>
              <p className="text-xs text-gray-600">{book.author} | {book.type}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function FiqhSection({ language }: { language: Language }) {
  const data = fiqhBooks.en;
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-red-700 to-rose-800 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">{data.title}</h2>
        <p className="text-red-200 text-xs">{language === 'en' ? 'Essential references for Islamic jurisprudence' : language === 'ur' ? 'اسلامی فقہ کے بنیادی مراجع' : 'مراجع أساسية للفقه الإسلامي'}</p>
      </div>

      {/* Fiqh Books */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-red-100">
        <h3 className="text-red-800 font-bold text-sm mb-3">
          {language === 'en' ? '📕 Primary Hanafi Fiqh Books' : language === 'ur' ? '📕 بنیادی حنفی فقہ کی کتب' : '📕 كتب الفقه الحنفي الأساسية'}
        </h3>
        <div className="space-y-3">
          {data.primary.map((book, i) => (
            <div key={i} className="bg-red-50 rounded-lg p-3">
              <p className="font-semibold text-sm text-red-900">{book.name}</p>
              <p className="text-xs text-gray-600">{book.author}</p>
              <p className="text-xs text-gray-500 mt-1">{book.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Hadith Books */}
      <div className="bg-white rounded-2xl p-5 shadow-md border border-teal-100">
        <h3 className="text-teal-800 font-bold text-sm mb-3">
          {language === 'en' ? '📗 Major Hadith Collections' : language === 'ur' ? '📗 بڑی کتب حدیث' : '📗 مجموعات الحديث الكبرى'}
        </h3>
        <div className="space-y-3">
          {data.hadithBooks.map((book, i) => (
            <div key={i} className="bg-teal-50 rounded-lg p-3">
              <p className="font-semibold text-sm text-teal-900">{book.name}</p>
              <p className="text-xs text-gray-600">{book.author}</p>
              <p className="text-xs text-gray-500 mt-1">{book.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MosquesSection({ language }: { language: Language }) {
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(false);

  const findNearby = () => {
    setLoading(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          setLoading(false);
        },
        () => {
          setLoading(false);
          alert(language === 'en' ? 'Location access denied. Please enable location.' : language === 'ur' ? 'لوکیشن کی اجازت نہیں ملی' : 'تم رفض الوصول للموقع');
        }
      );
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-teal-600 to-green-700 rounded-2xl p-5 text-white text-center">
        <h2 className="text-xl font-bold mb-1">
          {language === 'en' ? '🗺️ Nearby Sunni Mosques' : language === 'ur' ? '🗺️ قریبی سنی مساجد' : '🗺️ المساجد السنية القريبة'}
        </h2>
        <p className="text-teal-200 text-xs">
          {language === 'en' ? 'Find mosques near you' : language === 'ur' ? 'اپنے قریب مساجد تلاش کریں' : 'ابحث عن مساجد قريبة'}
        </p>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-md border border-teal-100">
        <button
          onClick={findNearby}
          disabled={loading}
          className="w-full bg-teal-700 text-white py-3 rounded-xl font-semibold text-sm hover:bg-teal-800 transition disabled:opacity-50"
        >
          {loading ? (language === 'en' ? '⏳ Loading...' : '⏳ لوڈ ہو رہا ہے...') :
           (language === 'en' ? '📍 Find Mosques Near Me' : language === 'ur' ? '📍 قریبی مساجد تلاش کریں' : '📍 ابحث عن مساجد قريبة')}
        </button>

        {location && (
          <div className="mt-4">
            <div className="bg-teal-50 rounded-xl p-4 mb-4">
              <p className="text-xs text-teal-700 font-medium mb-2">
                {language === 'en' ? '📍 Your Location' : language === 'ur' ? '📍 آپ کی لوکیشن' : '📍 موقعك'}
              </p>
              <p className="text-sm text-gray-700">Lat: {location.lat.toFixed(4)}, Lng: {location.lng.toFixed(4)}</p>
            </div>

            <iframe
              title="Nearby Mosques"
              width="100%"
              height="300"
              className="rounded-xl border border-gray-200"
              src={`https://www.openstreetmap.org/export/embed.html?bbox=${location.lng - 0.05},${location.lat - 0.03},${location.lng + 0.05},${location.lat + 0.03}&layer=mapnik&marker=${location.lat},${location.lng}`}
            />

            <a
              href={`https://www.google.com/maps/search/mosque+sunni/@${location.lat},${location.lng},14z`}
              target="_blank"
              rel="noopener noreferrer"
              className="block mt-3 text-center bg-blue-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-blue-700 transition"
            >
              {language === 'en' ? '🔍 Open in Google Maps' : language === 'ur' ? '🔍 گوگل میپس میں کھولیں' : '🔍 فتح في خرائط جوجل'}
            </a>
          </div>
        )}
      </div>

      <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200">
        <h4 className="text-amber-800 font-bold text-sm mb-2">
          {language === 'en' ? '💡 Tips for Finding Mosques' : language === 'ur' ? '💡 مساجد تلاش کرنے کے ٹپس' : '💡 نصائح للبحث عن مساجد'}
        </h4>
        <ul className="text-xs text-gray-700 space-y-1">
          <li>• {language === 'en' ? 'Use Google Maps search "Sunni mosque near me"' : language === 'ur' ? 'گوگل میپس میں "سنی مسجد" سرچ کریں' : 'ابحث في خرائط جوجل'}</li>
          <li>• {language === 'en' ? 'Check prayer times on local mosque websites' : language === 'ur' ? 'مقامی مسجد کی ویب سائٹ پر نماز کے اوقات دیکھیں' : 'تحقق من أوقات الصلاة'}</li>
          <li>• {language === 'en' ? 'Ask local Islamic centers for guidance' : language === 'ur' ? 'مقامی اسلامی مراکز سے رہنمائی لیں' : 'اسأل المراكز الإسلامية المحلية'}</li>
        </ul>
      </div>
    </div>
  );
}

export const quranVerses = [
  {
    id: 1,
    arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
    translation_en: "In the name of Allah, the Most Gracious, the Most Merciful",
    translation_ur: "اللہ کے نام سے جو بڑا مہربان نہایت رحم والا ہے",
    reference: "Surah Al-Fatihah 1:1",
    surah: "Al-Fatihah"
  },
  {
    id: 2,
    arabic: "إِنَّ الصَّلَاةَ كَانَتْ عَلَى الْمُؤْمِنِينَ كِتَابًا مَّوْقُوتًا",
    translation_en: "Indeed, prayer has been decreed upon the believers at specified times",
    translation_ur: "بے شک نماز مومنوں پر مقررہ اوقات میں فرض کی گئی ہے",
    reference: "Surah An-Nisa 4:103",
    surah: "An-Nisa"
  },
  {
    id: 3,
    arabic: "وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ",
    translation_en: "And establish prayer and give zakat",
    translation_ur: "اور نماز قائم کرو اور زکوٰ دو",
    reference: "Surah Al-Baqarah 2:43",
    surah: "Al-Baqarah"
  },
  {
    id: 4,
    arabic: "وَلِلَّهِ عَلَى النَّاسِ حِجُّ الْبَيْتِ مَنِ اسْتَطَاعَ إِلَيْهِ سَبِيلًا",
    translation_en: "And [due] to Allah from the people is a pilgrimage to the House - for whoever is able to find thereto a way",
    translation_ur: "اور اللہ کا لوگوں پر اس گھر کا حج ہے جس کو اس کی طرف پہنچنے کی سکت ہو",
    reference: "Surah Aal-e-Imran 3:97",
    surah: "Aal-e-Imran"
  },
  {
    id: 5,
    arabic: "يَا أَيُّهَا الَّذِينَ آمَنُوا ارْكَعُوا وَاسْجُدُوا وَاعْبُدُوا رَبَّكُمْ",
    translation_en: "O you who have believed, bow and prostrate and worship your Lord",
    translation_ur: "اے ایمان والو! رکوع کرو اور سجدے کرو اور اپنے رب کی عبادت کرو",
    reference: "Surah Al-Hajj 22:77",
    surah: "Al-Hajj"
  }
];

export const hadithCollection = [
  {
    id: 1,
    text_en: "Actions are judged by intentions, and every person will get what they intended.",
    text_ur: "اعمال کا دارومدار نیتوں پر ہے اور ہر شخص کو وہی ملے گا جس کی اس نے نیت کی",
    text_ar: "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
    source: "Sahih Al-Bukhari, Hadith 1",
    narrator: "Umar ibn al-Khattab (RA)",
    book: "Bukhari"
  },
  {
    id: 2,
    text_en: "The best among you are those who learn the Quran and teach it.",
    text_ur: "تم میں سے بہترین وہ ہے جو قرآن سیکھے اور سکھائے",
    text_ar: "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ",
    source: "Sahih Al-Bukhari, Hadith 5027",
    narrator: "Uthman ibn Affan (RA)",
    book: "Bukhari"
  },
  {
    id: 3,
    text_en: "The prayer is the pillar of religion. Whoever establishes it, establishes the religion.",
    text_ur: "نماز دین کا ستون ہے جس نے اسے قائم کیا اس نے دین قائم کیا",
    text_ar: "الصَّلَاةُ عَمُودُ الدِّينِ",
    source: "Sunan Al-Bayhaqi",
    narrator: "Muadh ibn Jabal (RA)",
    book: "Bayhaqi"
  },
  {
    id: 4,
    text_en: "Islam is built upon five pillars: testimony that there is no god but Allah and Muhammad is His messenger, establishing prayer, paying zakat, performing Hajj, and fasting in Ramadan.",
    text_ur: "اسلام پانچ بنیادوں پر قائم ہے: اس کی گواہی کہ اللہ کے سوا کوئی معبود نہیں اور محمد اس کے رسول ہیں، نماز قائم کرنا، زکوٰ دینا، حج کرنا اور رمضان کے روزے رکھنا",
    text_ar: "بُنِيَ الْإِسْلَامُ عَلَى خَمْسٍ شَهَادَةِ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَأَنَّ مُحَمَّدًا رَسُولُ اللَّهِ وَإِقَامِ الصَّلَاةِ وَإِيتَاءِ الزَّكَاةِ وَالْحَجِّ وَصَوْمِ رَمَضَانَ",
    source: "Sahih Al-Bukhari, Hadith 8; Sahih Muslim, Hadith 16",
    narrator: "Abdullah ibn Umar (RA)",
    book: "Bukhari"
  },
  {
    id: 5,
    text_en: "The truthful and trustworthy merchant will be with the prophets, the truthful, and the martyrs.",
    text_ur: "سچا اور امانت دار تاجر قیامت کے دن نبیوں صدیقوں اور شہیدوں کے ساتھ ہوگا",
    text_ar: "التَّاجِرُ الصَّدِيقُ الْأَمِينُ مَعَ النَّبِيِّينَ وَالصِّدِّيقِينَ وَالشُّهَدَاءِ",
    source: "Jami at-Tirmidhi, Hadith 1209",
    narrator: "Abu Sa'id al-Khudri (RA)",
    book: "Tirmidhi"
  },
  {
    id: 6,
    text_en: "Whoever does not show mercy to the young and respect to the old is not one of us.",
    text_ur: "جو ہمارے چھوٹوں پر رحم نہ کرے اور بڑوں کا ادب نہ کرے وہ ہم میں سے نہیں",
    text_ar: "مَنْ لَمْ يَرْحَمْ صَغِيرَنَا وَيُوَقِّرْ كَبِيرَنَا فَلَيْسَ مِنَّا",
    source: "Jami at-Tirmidhi, Hadith 1919",
    narrator: "Abdullah ibn Amr (RA)",
    book: "Tirmidhi"
  }
];

export const wuzuSteps = {
  en: {
    title: "How to Perform Wudu (Ablution)",
    fard: ["1. Wash the face once (fard)", "2. Wash both arms including elbows once (fard)", "3. Wipe one-fourth of the head (fard)", "4. Wash both feet including ankles once (fard)"],
    sunnah: [
      "1. Make intention (Niyyah) - 'I intend to perform Wudu for the sake of Allah'",
      "2. Say Bismillah",
      "3. Wash both hands up to wrists three times",
      "4. Rinse the mouth three times",
      "5. Clean the nose by sniffing water and blowing it out three times",
      "6. Wash the entire face three times",
      "7. Wash the right arm to elbow three times, then the left",
      "8. Wipe the entire head once with wet hands",
      "9. Clean the ears with wet fingers",
      "10. Wash the right foot up to ankle three times, then the left",
      "11. Recite the testimony after Wudu"
    ],
    dua: "أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
    duaTranslation: "I bear witness that there is no god but Allah, alone, without partner, and I bear witness that Muhammad is His servant and Messenger.",
    reference: "Sahih Muslim, Hadith 226; Sunan Abu Dawud, Hadith 142",
    fiqhNote: "According to Hanafi Fiqh: Washing each part once is Fard, twice is Wajib, and three times is Sunnah. The mouth and nose must be rinsed thoroughly (Khalal madmada and istinshaq)."
  },
  ur: {
    title: "وضو کا طریقہ",
    fard: ["1. چہرہ ایک بار دھونا (فرض)", "2. کہنیوں سمیت دونوں ہاتھ ایک بار دھونا (فرض)", "3. سر کا چوتھائی حصہ مسح کرنا (فرض)", "4. ٹخنوں سمیت دونوں پاؤں ایک بار دھونا (فرض)"],
    sunnah: [
      "1. نیت کرو - 'میں اللہ کی رضا کے لیے وضو کرنے کا ارادہ کرتا ہوں'",
      "2. بسم اللہ پڑھو",
      "3. دونوں ہاتھ کلائیوں تک تین بار دھو",
      "4. تین بار کلی کرو",
      "5. تین بار ناک میں پانی ڈال کر صاف کرو",
      "6. تین بار پورا چہرہ دھو",
      "7. کہنیوں سمیت داہنا ہاتھ تین بار پھر بایاں",
      "8. سر کا مسح ایک بار گیلے ہاتھوں سے کرو",
      "9. گیلے ہاتھوں سے کان صاف کرو",
      "10. ٹخنوں سمیت دایاں پاؤں تین بار پھر بایاں",
      "11. وضو کے بعد کلمہ پڑھو"
    ],
    dua: "أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
    duaTranslation: "میں گواہی دیتا ہوں کہ اللہ کے سوا کوئی معبود نہیں اور محمد اس کے رسول ہیں",
    reference: "صحیح مسلم حدیث 226، سنن ابی داؤد حدیث 142",
    fiqhNote: "حنفی فقہ کے مطابق: ہر عضو ایک بار دھونا فرض، دو بار واجب، تین بار سنت ہے۔ کلی اور استنشاق پوری طرح کرنا ضروری ہے۔"
  },
  ar: {
    title: "كيفية أداء الوضوء",
    fard: ["١. غسل الوجه مرة (فرض)", "٢. غسل اليدين إلى المرفقين مرة (فرض)", "٣. مسح ربع الرأس (فرض)", "٤. غسل القدمين إلى الكعبين مرة (فرض)"],
    sunnah: [
      "١. النية",
      "٢. التسمية (بسم الله)",
      "٣. غسل الكفين ثلاثاً",
      "٤. المضمضة ثلاثاً",
      "٥. الاستنشاق والاستنثار ثلاثاً",
      "٦. غسل الوجه ثلاثاً",
      "٧. غسل اليدين إلى المرفقين ثلاثاً",
      "٨. مسح الرأس",
      "٩. مسح الأذنين",
      "١٠. غسل الرجلين إلى الكعبين ثلاثاً",
      "١١. قراءة الشهادة بعد الوضوء"
    ],
    dua: "أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
    duaTranslation: "أشهد أن لا إله إلا الله وحده لا شريك له وأشهد أن محمداً عبده ورسوله",
    reference: "صحيح مسلم حديث 226، سنن أبي داود حديث 142",
    fiqhNote: "حسب الفقه الحنفي: غسل كل عضو مرة فرض، ومرتين واجب، وثلاثاً سنة"
  }
};

export const salahGuide = {
  en: {
    title: "Complete Guide to Salah (Namaz)",
    dailyPrayers: [
      { name: "Fajr", time: "Before sunrise (Dawn)", rakaat: "2 Sunnah + 2 Fard", total: 4 },
      { name: "Dhuhr", time: "After midday", rakaat: "4 Sunnah + 4 Fard + 2 Sunnah", total: 12 },
      { name: "Asr", time: "Late afternoon", rakaat: "4 Sunnah + 4 Fard", total: 8 },
      { name: "Maghrib", time: "After sunset", rakaat: "3 Fard + 2 Sunnah + 2 Nafl", total: 7 },
      { name: "Isha", time: "Night time", rakaat: "4 Sunnah + 4 Fard + 2 Sunnah + 2 Nafl + 3 Witr", total: 17 }
    ],
    steps: [
      "1. Stand facing Qiblah (Qiyam) - Make Niyyah (intention)",
      "2. Raise both hands to ears (men) / shoulders (women) saying 'Allahu Akbar'",
      "3. Place right hand over left on chest/navel - Recite Thana (Subhanaka)",
      "4. Recite Ta'awwuz (A'udhu billah...)",
      "5. Recite Tasmiah (Bismillah...)",
      "6. Recite Surah Al-Fatihah completely",
      "7. Recite another Surah or at least 3 verses (in first 2 rakaat)",
      "8. Say 'Allahu Akbar' and go into Ruku - Say 'Subhana Rabbiyal Azeem' 3 times",
      "9. Rise from Ruku saying 'Sami'allahu liman hamidah' then 'Rabbana lakal hamd'",
      "10. Say 'Allahu Akbar' and go into first Sujud - Say 'Subhana Rabbiyal A'la' 3 times",
      "11. Sit between two Sujuds saying 'Rabbighfirli'",
      "12. Second Sujud - Same as first",
      "13. After 2 rakaat, sit for Tashahhud (Attahiyyat)",
      "14. In last rakaat, complete Tashahhud, Durood Ibrahim, and Dua",
      "15. End with Salam - Turn head right saying 'Assalamu alaikum wa rahmatullah', then left"
    ],
    importantRecitations: {
      thana: { arabic: "سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ وَتَبَارَكَ اسْمُكَ وَتَعَالَى جَدُّكَ وَلَا إِلَهَ غَيْرُكَ", translation: "Glory be to You, O Allah, and all praises are due unto You, and blessed is Your name and high is Your majesty and none is worthy of worship but You." },
      tashahhud: { arabic: "التَّحِيَّاتُ لِلَّهِ وَالصَّلَوَاتُ وَالطَّيِّبَاتُ، السَّلَامُ عَلَيْكَ أَيُّهَا النَّبِيُّ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ", translation: "All greetings, prayers and good things are due to Allah. Peace be upon you, O Prophet, and the mercy of Allah and His blessings." },
      durood: { arabic: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ", translation: "O Allah, send blessings upon Muhammad and upon the family of Muhammad, as You sent blessings upon Ibrahim and upon the family of Ibrahim. Indeed, You are Praiseworthy and Glorious." }
    },
    reference: "Sahih Al-Bukhari, Book of Salah; Radd al-Muhtar (Ibn Abidin), Hanafi Fiqh",
    fiqhNotes: [
      "According to Hanafi Fiqh, raising hands is only done at the first Takbeer (Takbeer-e-Tahreema)",
      "In Hanafi Fiqh, Bismillah is recited silently before Al-Fatihah",
      "Qunut in Witr is Wajib according to Hanafi Fiqh",
      "Sadr (chest) binding: hands below navel for men, on chest for women (Hanafi)",
      "In the 3rd and 4th rakaat, only Surah Al-Fatihah is recited (according to Hanafi)"
    ]
  }
};

export const zakatInfo = {
  en: {
    title: "Zakat - Complete Guide & Calculator",
    nisaab: {
      gold: "87.48 grams (20 mithqal) of gold",
      silver: "612.36 grams (200 dirhams) of silver",
      cash: "Value equivalent to 612.36g silver"
    },
    rate: "2.5% (1/40th) of total wealth above Nisaab",
    eligibleRecipients: [
      "1. Fuqara (The Poor) - Those who don't have enough",
      "2. Masakeen (The Needy) - Those in extreme poverty",
      "3. Amileen (Zakat Collectors) - Those appointed to collect",
      "4. Mu'allafat-ul-Quloob (New Muslims) - To strengthen their faith",
      "5. Ar-Riqab (Slaves) - To free captives",
      "6. Al-Gharimeen (Debtors) - Those burdened with debt",
      "7. Fi Sabilillah (In the way of Allah) - For Islamic causes",
      "8. Ibn as-Sabil (Wayfarer) - Stranded travelers"
    ],
    reference: "Surah At-Tawbah 9:60; Hedaya (Hanafi Fiqh), Kitab az-Zakat",
    notEligible: [
      "Parents, grandparents, children, grandchildren",
      "Spouse",
      "Hashimi and Muttalibi (descendants of Prophet ﷺ)",
      "Non-Muslims (according to majority Hanafi view)"
    ],
    calculation: {
      items: [
        "Cash in hand and bank accounts",
        "Gold and silver (market value)",
        "Stocks and investments (current value)",
        "Business merchandise (wholesale value)",
        "Money lent to others (expected to be returned)",
        "Rental income saved",
        "Provident fund (if accessible)"
      ],
      deductions: [
        "Immediate debts and liabilities",
        "Money owed to others",
        "Due bills and expenses"
      ]
    }
  }
};

export const hajjGuide = {
  en: {
    title: "Complete Hajj Guide (Hanafi Fiqh)",
    prerequisites: [
      "1. Islam - Must be Muslim",
      "2. Sanity (Aql) - Must be of sound mind",
      "3. Puberty (Bulugh) - Must have reached puberty",
      "4. Freedom (Hurriyat) - Must be free, not enslaved",
      "5. Ability (Istita'ah) - Physical and financial capability",
      "6. Mahram for women - Must travel with a mahram"
    ],
    mawaqit: [
      { name: "Dhul Hulayfah (Abyar Ali)", for: "People of Madinah", distance: "450 km from Makkah" },
      { name: "Al-Juhfah", for: "People of Syria/Egypt", distance: "187 km from Makkah" },
      { name: "Qarn al-Manazil", for: "People of Najd", distance: "94 km from Makkah" },
      { name: "Yalamlam (As-Sa'diyah)", for: "People of Yemen", distance: "120 km from Makkah" },
      { name: "Dhat Irq", for: "People of Iraq", distance: "94 km from Makkah" }
    ],
    steps: [
      { day: "8th Dhul Hijjah (Yawm ut-Tarwiyah)", actions: ["Enter Ihram from Miqat or Makkah", "Proceed to Mina", "Offer Dhuhr, Asr, Maghrib, Isha, and Fajr prayers in Mina", "Stay overnight in Mina"] },
      { day: "9th Dhul Hijjah (Yawm ul-Arafah)", actions: ["After Fajr, proceed to Arafat", "Offer combined Dhuhr and Asr (Jama Taqdeem)", "Stay in Arafat from after Zawal till Maghrib", "Make abundant dua and repentance", "After sunset, proceed to Muzdalifah", "Offer combined Maghrib and Isha at Muzdalifah", "Collect 7 pebbles for Jamarat", "Stay overnight at Muzdalifah"] },
      { day: "10th Dhul Hijjah (Yawm un-Nahr)", actions: ["After Fajr, proceed to Mina", "Rami: Throw 7 pebbles at Jamarat al-Aqabah", "Sacrifice animal (Qurbani)", "Shave head (men) / trim hair (women)", "Remove Ihram (first release - all restrictions except intimacy)", "Proceed to Makkah for Tawaf al-Ifadah and Sa'i", "Return to Mina for the night"] },
      { day: "11th Dhul Hijjah (Yawm ul-Qarr)", actions: ["Throw 7 pebbles at each of the three Jamarat", "Each Jamarat: Start from Sughra, then Wusta, then Aqabah", "Make dua after Sughra and Wusta", "Stay in Mina"] },
      { day: "12th Dhul Hijjah", actions: ["If leaving before Maghrib: Throw pebbles at three Jamarat, then leave", "If staying till Maghrib: Throw pebbles and stay for 13th"] },
      { day: "13th Dhul Hijjah (optional)", actions: ["Throw pebbles at three Jamarat", "Proceed to Makkah"] },
      { day: "After Hajj", actions: ["Perform Tawaf as-Sadr (Farewell Tawaf) - Wajib", "This is the last act before leaving Makkah"] }
    ],
    ihramProhibitions: [
      "Cutting hair or nails",
      "Using perfume or scented products",
      "Hunting or killing animals",
      "Cutting trees or plants in Haram",
      "Marriage or proposing marriage",
      "Intimate relations with spouse",
      "Covering head (men) / face (women)",
      "Wearing stitched clothing (men)",
      "Wearing gloves or socks (men - according to Hanafi)"
    ],
    reference: "Sahih Al-Bukhari, Book of Hajj; Al-Hidayah by Al-Marghinani; Radd al-Muhtar (Ibn Abidin)"
  }
};

export const umrahGuide = {
  en: {
    title: "Complete Umrah Guide (Hanafi Fiqh)",
    title_ar: "عمرة",
    steps: [
      { step: 1, name: "Ihram", description: "Enter state of Ihram at the Miqat", details: ["Perform Ghusl or Wudu", "Wear Ihram garments (men: two white sheets)", "Make intention: 'O Allah, I intend to perform Umrah'", "Recite Talbiyah continuously: لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ'"] },
      { step: 2, name: "Tawaf", description: "Circumambulate the Ka'bah 7 times", details: ["Enter Masjid al-Haram with right foot", "Start Tawaf from Hajr al-Aswad (Black Stone)", "Perform Ramal (fast walking) in first 3 circuits (men only)", "Complete 7 circuits with Ka'bah on your left", "Pray 2 rakaat behind Maqam Ibrahim", "Drink Zamzam water"] },
      { step: 3, name: "Sa'i", description: "Walk between Safa and Marwah 7 times", details: ["Start from Safa (climb up)", "Face the Ka'bah and make dua", "Walk to Marwah (men: run between green lights)", "This counts as 1 trip", "Continue till 7 trips are complete", "End at Marwah"] },
      { step: 4, name: "Halq/Taqsir", description: "Shave or trim the hair", details: ["Men: Shave head completely (Halq) - preferred, or trim (Taqsir)", "Women: Trim a fingertip length of hair", "After this, Umrah is complete", "All Ihram restrictions are lifted"] }
    ],
    talbiyah: {
      arabic: "لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لَا شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لَا شَرِيكَ لَكَ",
      translation: "Here I am at Your service, O Allah, here I am. Here I am, You have no partner, here I am. Verily all praise and blessings are Yours, and all sovereignty, You have no partner."
    },
    reference: "Sahih Muslim, Book of Hajj; Al-Hidayah; Fatawa Alamgiri"
  }
};

export const islamicBusiness = {
  en: {
    title: "Islamic Business Principles & Ideas",
    principles: [
      { principle: "No Riba (Interest)", detail: "All forms of interest are strictly prohibited", reference: "Surah Al-Baqarah 2:275-279" },
      { principle: "No Gharar (Uncertainty/Deception)", detail: "Transactions must be clear and transparent", reference: "Sahih Muslim, Hadith 1513" },
      { principle: "No Maysir (Gambling)", detail: "All forms of gambling and speculation are haram", reference: "Surah Al-Ma'idah 5:90" },
      { principle: "Halal Products Only", detail: "Business must deal in permissible goods and services", reference: "Surah Al-Baqarah 2:168" },
      { principle: "Honesty in Dealings", detail: "Must be truthful about product quality and quantity", reference: "Sahih Al-Bukhari, Hadith 2079" },
      { principle: "Fair Pricing", detail: "No price manipulation or hoarding", reference: "Sunan Abu Dawud, Hadith 3452" },
      { principle: "Written Contracts", detail: "Business agreements should be documented", reference: "Surah Al-Baqarah 2:282" },
      { principle: "Zakat on Business", detail: "Pay 2.5% zakat on business assets annually", reference: "Surah At-Tawbah 9:103" }
    ],
    businessIdeas: [
      "Halal Food & Restaurant Business",
      "Islamic Clothing & Modest Fashion",
      "Islamic Education & Tutoring",
      "Halal Investment & Finance Advisory",
      "Islamic Publishing & Books",
      "Halal Cosmetics & Personal Care",
      "Islamic App & Software Development",
      "Halal Travel & Tourism Agency",
      "Islamic Calligraphy & Art",
      "Dates & Dry Fruits Trading",
      "Perfume & Oud Business",
      "Islamic Wedding Planning",
      "Halal Meat & Poultry",
      "Islamic Finance Education",
      "Prayer Mats & Islamic Decor"
    ],
    reference: "Kitab al-Kasb by Imam Muhammad ash-Shaybani; Al-Hidayah, Book of Trade"
  }
};

export const islamicHistory = {
  en: {
    title: "Islamic History Timeline",
    periods: [
      {
        era: "Prophetic Era (610-632 CE)",
        events: [
          "610 CE - First revelation in Cave Hira",
          "613 CE - Public preaching begins in Makkah",
          "615 CE - Migration to Abyssinia",
          "622 CE - Hijrah to Madinah",
          "624 CE - Battle of Badr",
          "625 CE - Battle of Uhud",
          "627 CE - Battle of the Trench (Khandaq)",
          "628 CE - Treaty of Hudaybiyyah",
          "630 CE - Conquest of Makkah",
          "632 CE - Farewell Hajj and passing of Prophet ﷺ"
        ]
      },
      {
        era: "Khulafa-e-Rashideen (632-661 CE)",
        events: [
          "632-634 CE - Caliphate of Abu Bakr (RA)",
          "634-644 CE - Caliphate of Umar ibn al-Khattab (RA)",
          "644-656 CE - Caliphate of Uthman ibn Affan (RA)",
          "656-661 CE - Caliphate of Ali ibn Abi Talib (RA)"
        ]
      },
      {
        era: "Umayyad Dynasty (661-750 CE)",
        events: [
          "Expansion to Spain, North Africa, Central Asia",
          "Arabic becomes official language",
          "Construction of Dome of the Rock"
        ]
      },
      {
        era: "Abbasid Dynasty (750-1258 CE)",
        events: [
          "Golden Age of Islam",
          "House of Wisdom (Bayt al-Hikmah) established",
          "Development of Islamic sciences, mathematics, medicine",
          "Imam Abu Hanifa (699-767 CE) - Founder of Hanafi school",
          "Imam Malik (711-795 CE) - Founder of Maliki school",
          "Imam Shafi'i (767-820 CE) - Founder of Shafi'i school",
          "Imam Ahmad ibn Hanbal (780-855 CE) - Founder of Hanbali school",
          "Imam Bukhari (810-870 CE) - Compiler of Sahih al-Bukhari",
          "Imam Muslim (815-875 CE) - Compiler of Sahih Muslim"
        ]
      },
      {
        era: "Ottoman Empire (1299-1924 CE)",
        events: [
          "1453 - Conquest of Constantinople",
          "Vast empire spanning three continents",
          "Preservation and development of Islamic arts"
        ]
      },
      {
        era: "Mughal Empire in India (1526-1857 CE)",
        events: [
          "1526 - Babur establishes Mughal Empire",
          "Akbar's reign - administrative reforms",
          "Shah Jahan - Taj Mahal construction",
          "Aurangzeb - compilation of Fatawa Alamgiri"
        ]
      }
    ],
    recommendedBooks: [
      { title: "Seerah Ibn Hisham", author: "Ibn Hisham", type: "Prophetic Biography" },
      { title: "Tarikh al-Tabari", author: "Imam at-Tabari", type: "Universal History" },
      { title: "Al-Bidayah wan-Nihayah", author: "Ibn Kathir", type: "History from Creation" },
      { title: "Tarikh al-Khulafa", author: "Imam as-Suyuti", type: "History of Caliphs" },
      { title: "Al-Kamil fit-Tarikh", author: "Ibn al-Athir", type: "Complete History" },
      { title: "Wafayat al-A'yan", author: "Ibn Khallikan", type: "Biographical Dictionary" },
      { title: "Fatawa Alamgiri", author: "Scholars under Aurangzeb", type: "Hanafi Legal Compilation" },
      { title: "Al-Hidayah", author: "Al-Marghinani", type: "Hanafi Fiqh Manual" },
      { title: "Radd al-Muhtar", author: "Ibn Abidin", type: "Hanafi Fiqh Commentary" },
      { title: "Bahar-e-Shariat", author: "Allama Amjad Ali", type: "Hanafi Fiqh (Urdu)" }
    ]
  }
};

export const ethicsAndAkhlaq = {
  en: {
    title: "Islamic Ethics & Morals (Akhlaq)",
    coreVirtues: [
      { virtue: "Truthfulness (Sidq)", description: "Always speak the truth in all matters", hadith: "Truthfulness leads to righteousness, and righteousness leads to Paradise. (Sahih Muslim)" },
      { virtue: "Trustworthiness (Amanah)", description: "Fulfill all trusts and responsibilities", hadith: "The Prophet ﷺ was known as Al-Amin (The Trustworthy) even before prophethood" },
      { virtue: "Patience (Sabr)", description: "Remain patient in adversity", hadith: "How wonderful is the affair of the believer! His affairs are all good... If something good happens he is grateful, and if something bad happens he is patient. (Sahih Muslim)" },
      { virtue: "Humility (Tawadu)", description: "Be humble with all people", hadith: "No one who has the weight of a seed of arrogance in his heart will enter Paradise. (Sahih Muslim)" },
      { virtue: "Generosity (Karam)", description: "Give freely to those in need", hadith: "The believer's shade on the Day of Resurrection will be his charity. (Ahmad)" },
      { virtue: "Justice (Adl)", description: "Be just even against yourself", hadith: "Be just, that is nearer to righteousness. (Surah Al-Ma'idah 5:8)" },
      { virtue: "Forgiveness (Afw)", description: "Forgive others as you hope Allah forgives you", hadith: "Show mercy to those on earth, and the One in the heavens will show mercy to you. (Tirmidhi)" },
      { virtue: "Good Character (Husn al-Khuluq)", description: "Maintain excellent character with everyone", hadith: "The best of you are those who have the best character. (Sahih Al-Bukhari)" }
    ],
    rightsInIslam: [
      "Rights of Allah - Tawheed, worship, obedience",
      "Rights of Parents - Respect, care, obedience (in good)",
      "Rights of Children - Proper upbringing, education, love",
      "Rights of Spouse - Kindness, provision, fair treatment",
      "Rights of Neighbors - Good conduct, help, respect",
      "Rights of Relatives - Maintaining family ties (Silat ar-Rahim)",
      "Rights of the Poor - Zakat, Sadaqah, assistance",
      "Rights of Guests - Hospitality and generosity",
      "Rights of the Road - No harm, removing obstacles"
    ],
    reference: "Ihya Ulum al-Din by Imam al-Ghazali; Riyad as-Salihin by Imam an-Nawawi"
  }
};

export const jihadInfo = {
  en: {
    title: "Understanding Jihad in Islam",
    types: [
      { type: "Jihad bin-Nafs (Jihad of the Self)", description: "Struggling against one's own desires and temptations", importance: "The Greatest Jihad - mentioned in hadith as returning from the lesser to the greater jihad" },
      { type: "Jihad bil-Lisan (Jihad of the Tongue)", description: "Speaking the truth, spreading knowledge, advising good", importance: "The best Jihad is a word of truth before a tyrant ruler (Abu Dawud)" },
      { type: "Jihad bil-Qalam (Jihad of the Pen)", description: "Writing, teaching, and spreading Islamic knowledge", importance: "Scholars are the inheritors of the prophets" },
      { type: "Jihad bil-Mal (Jihad of Wealth)", description: "Spending wealth for the cause of Allah", importance: "The mujahid in the path of Allah and the one who spends wealth... (Quran)" },
      { type: "Jihad bis-Saif (Jihad of the Sword)", description: "Armed struggle - strictly regulated with conditions", importance: "Only under legitimate authority, defensive, with strict rules of engagement" }
    ],
    conditions: [
      "Must be declared by legitimate Islamic authority",
      "Must be defensive or against oppression",
      "Non-combatants must not be harmed",
      "Women, children, elderly, and monks must be protected",
      "Trees, crops, and infrastructure must not be destroyed",
      "Prisoners must be treated humanely",
      "Peace must be accepted if offered by the enemy"
    ],
    reference: "Surah Al-Baqarah 2:190-193; Surah Al-Hajj 22:39-40; Sahih Muslim; Al-Hidayah, Book of Jihad"
  }
};

export const fiqhBooks = {
  en: {
    title: "Essential Hanafi Fiqh Books",
    primary: [
      { name: "Al-Hidayah", author: "Burhan al-Din al-Marghinani (d. 1197)", description: "The most authoritative Hanafi fiqh manual, extensively commented upon" },
      { name: "Radd al-Muhtar (Ibn Abidin)", author: "Muhammad Amin Ibn Abidin (d. 1836)", description: "The primary reference for Hanafi fatwa in the later period, known as 'ash-Shami'" },
      { name: "Al-Mabsut (as-Sarakhsi)", author: "Shams al-A'immah as-Sarakhsi (d. 1090)", description: "Comprehensive encyclopedia of Hanafi fiqh, 30 volumes" },
      { name: "Fatawa Alamgiri", author: "Compiled under Aurangzeb (1664-1710)", description: "Major compilation of Hanafi rulings, also known as Fatawa Hindiyyah" },
      { name: "Nur al-Idah", author: "Hasan ash-Shurunbulali (d. 1659)", description: "Essential text on worship (ibadaat) - widely studied" },
      { name: "Mukhtasar al-Quduri", author: "Ahmad al-Quduri (d. 1037)", description: "Introductory text in Hanafi fiqh, most widely taught primer" },
      { name: "Bahar-e-Shariat", author: "Allama Amjad Ali A'zami (d. 1948)", description: "Comprehensive Hanafi fiqh in Urdu - very popular in South Asia" },
      { name: "Ahsan al-Fatawa", author: "Mufti Rasheed Ahmad (d. 2002)", description: "Contemporary Hanafi fatwa collection" }
    ],
    hadithBooks: [
      { name: "Sahih al-Bukhari", author: "Imam Bukhari (d. 870)", description: "Most authentic book of hadith after Quran" },
      { name: "Sahih Muslim", author: "Imam Muslim (d. 875)", description: "Second most authentic hadith collection" },
      { name: "Sunan Abu Dawud", author: "Imam Abu Dawud (d. 889)", description: "Collection focused on legal rulings" },
      { name: "Jami at-Tirmidhi", author: "Imam at-Tirmidhi (d. 892)", description: "Hadith collection with juristic analysis" },
      { name: "Sunan an-Nasa'i", author: "Imam an-Nasa'i (d. 915)", description: "Hadith collection with focus on authenticity" },
      { name: "Sunan Ibn Majah", author: "Imam Ibn Majah (d. 887)", description: "Sixth canonical hadith collection" },
      { name: "Muwatta Imam Malik", author: "Imam Malik (d. 795)", description: "Earliest hadith and fiqh compilation" },
      { name: "Musnad Ahmad", author: "Imam Ahmad ibn Hanbal (d. 855)", description: "Large hadith collection organized by narrator" }
    ]
  }
};
